function hide(id){
    document.getElementById(id).remove()
}
function hoverIn(img){
    img.src = "images/succulents-2.jpg"
}
function hoverOut(img){
    img.src = "images/succulents-1.jpg"
}